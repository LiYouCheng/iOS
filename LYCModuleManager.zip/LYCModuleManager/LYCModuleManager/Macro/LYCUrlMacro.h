//
//  LYCUrlMacro.h
//  LYCModuleManager
//
//  Created by YouchengLi on 2016/12/19.
//  Copyright © 2016年 深圳市齐家互联网科技股份有限公司. All rights reserved.
//

#ifndef LYCUrlMacro_h
#define LYCUrlMacro_h


#endif /* LYCUrlMacro_h */
